<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Room_Builder_Floors_16x16" tilewidth="16" tileheight="16" tilecount="600" columns="15">
 <image source="../../moderninteriors-win/1_Interiors/16x16/Room_Builder_subfiles/Room_Builder_Floors_16x16.png" trans="ff00ff" width="240" height="640"/>
</tileset>
