<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Modern_Exteriors_Complete_Tileset" tilewidth="16" tileheight="16" tilecount="55792" columns="176">
 <image source="../../modernexteriors-win/Modern_Exteriors_16x16/Modern_Exteriors_Complete_Tileset.png" trans="ff00ff" width="2816" height="5072"/>
 <tile id="900">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="901">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="1076">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="1077">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="2117">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="3184">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="5287">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
