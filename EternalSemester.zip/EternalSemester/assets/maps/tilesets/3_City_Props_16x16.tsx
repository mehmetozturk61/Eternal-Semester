<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="3_City_Props_16x16" tilewidth="16" tileheight="16" tilecount="3520" columns="32">
 <image source="../../modernexteriors-win/Modern_Exteriors_16x16/ME_Theme_Sorter_16x16/3_City_Props_16x16.png" trans="ff00ff" width="512" height="1760"/>
</tileset>
