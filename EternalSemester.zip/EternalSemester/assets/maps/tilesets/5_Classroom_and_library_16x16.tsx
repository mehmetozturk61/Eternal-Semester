<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="5_Classroom_and_library_16x16" tilewidth="16" tileheight="16" tilecount="544" columns="16">
 <image source="../../moderninteriors-win/1_Interiors/16x16/Theme_Sorter/5_Classroom_and_library_16x16.png" trans="ff00ff" width="256" height="544"/>
 <tile id="50">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="66">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="67">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="112">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="114">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="128">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="167">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="168">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="183">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="184">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="200">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="304">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="305">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="306">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="320">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="321">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="322">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="336">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="337">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="338">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="352">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="353">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="354">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="368">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="369">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="370">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="384">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="385">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="386">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="400">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="401">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
 <tile id="402">
  <properties>
   <property name="blocked" value=""/>
  </properties>
 </tile>
</tileset>
