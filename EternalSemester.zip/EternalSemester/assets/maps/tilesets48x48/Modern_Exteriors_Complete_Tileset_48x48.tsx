<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Modern_Exteriors_Complete_Tileset_48x48" tilewidth="48" tileheight="48" tilecount="55792" columns="176">
 <image source="../../modernexteriors-win/Modern_Exteriors_48x48/Modern_Exteriors_Complete_Tileset_48x48.png" trans="ff00ff" width="8448" height="15216"/>
</tileset>
