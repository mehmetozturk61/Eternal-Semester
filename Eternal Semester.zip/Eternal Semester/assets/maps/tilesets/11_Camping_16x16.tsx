<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="11_Camping_16x16" tilewidth="16" tileheight="16" tilecount="5792" columns="32">
 <image source="../../modernexteriors-win/Modern_Exteriors_16x16/ME_Theme_Sorter_16x16/11_Camping_16x16.png" trans="ff00ff" width="512" height="2896"/>
</tileset>
