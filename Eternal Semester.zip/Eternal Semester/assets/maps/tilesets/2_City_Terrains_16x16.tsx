<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="2_City_Terrains_16x16" tilewidth="16" tileheight="16" tilecount="4307" columns="59">
 <image source="../../modernexteriors-win/Modern_Exteriors_16x16/ME_Theme_Sorter_16x16/2_City_Terrains_16x16.png" trans="ff00ff" width="944" height="1168"/>
</tileset>
