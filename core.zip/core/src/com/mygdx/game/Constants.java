package com.mygdx.game;

public class Constants {
	public static final int VIEWPORT_WIDTH = 1600;
	public static final int VIEWPORT_HEIGHT = 900;
	public static final float ENEMY_SPAWN_BUFFER = 150f;
	public static final float PPM = 6f;

	//public static Tank player = new Tank();
}
